- 👋 Hi, I’m @For511Hd
- 👀 I’m interested in money,art
- 🌱 I’m currently learning how to make money
- 💞️ I’m looking to collaborate on my life
- 📫 How to reach me all of socal 
- 😄 Pronouns: fun
- ⚡ Fun fact: im funny

<!---
For511Hd/For511Hd is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
